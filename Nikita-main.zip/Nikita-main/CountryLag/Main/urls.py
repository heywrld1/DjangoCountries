from django.urls import path
from . import views

urlpatterns = [
    path('', views.about, name='about'),
    path('countries', views.countries, name='countries'),
    path('languages', views.languages, name='languages'),
    path('countries/<url_1>', views.country_l),
    path('languages/<url_2>', views.language_c),
]