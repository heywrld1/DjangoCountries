from django.db import models


class MainCountry(models.Model):
    country = models.CharField(max_length=50)
    languages = models.CharField(max_length=100)

