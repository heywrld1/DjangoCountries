from django.shortcuts import render
from django.core.paginator import Paginator
from .models import MainCountry

ABCD = 'A   B   C   D   E   F   G   H   I   J   K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z'


def about(request):
    return render(request, 'main/about.html')


def countries(request):
    a = []; array = MainCountry.objects.all()
    for i in array:
        a += [i.country]
    paginator = Paginator(a, 10); page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    a1 = {
        'array': a,
        'title': 'Countries',
        'mas': ABCD,
        'page_object': page_obj
    }

    return render(request, 'main/countries.html', a1)


def languages(request):
    a = []; array = MainCountry.objects.all()
    for i in array:
        b = str(i.languages)
        array_now = b.split(', ')
        for j in array_now:
            if j not in a:
                a += [j]

    a = set(a); a = sorted(a)
    paginator = Paginator(a, 15); page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    a1 = {
        'title': 'Языки',
        'array': a,
        'mas': ABCD,
        'page_object': page_obj
    }
    return render(request, 'main/languages.html', a1)


def country_l(request, url_1):
    a = []; b = 0; array = MainCountry.objects.all()
    if url_1 in ABCD:
        for i in array:
            if str(i.country)[0] == url_1:
                a += [i.country]

        paginator = Paginator(a, 10); page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        a1 = {
            'title': url_1,
            'array': a,
            'mas': ABCD,
            'page_object': page_obj
        }
        return render(request, 'main/countries.html', a1)
    else:
        for i in array:
            if i.country == url_1:
                b = i.languages
        a1 = {
            'title': url_1,
            'array': b,
        }
    return render(request, 'main/country_l.html', a1)


def language_c(request, url_2):
    a = []
    a2 = []
    a3 = []
    b = ''
    array = MainCountry.objects.all()
    if url_2 in ABCD:
        for i in array:
            b = str(i.languages)
            array_now = b.split(', ')
            for j in array_now:
                if j not in a2:
                    a2 += [j]

        a2 = set(a2); a2 = sorted(a2)
        for j in a2:
            if url_2 == j[0]:
                a3 += [j]
        paginator = Paginator(a3, 15); page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)

        array1 = {
            'title': url_2,
            'array': a3,
            'mas': ABCD,
            'page_object': page_obj
        }
        return render(request, 'main/languages.html', array1)
    else:
        for i in array:
            if url_2 in i.languages:
                b += i.country + ', '
        b = b[:-2]
        array1 = {
            'title': url_2,
            'array': b
        }
        return render(request, 'main/language_c.html', array1)
