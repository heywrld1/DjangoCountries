from Main.models import MainCountry
import json


json_file = open('home/student/Django/CountryLag/Skripts/country-by-languages.json')
for i in json.load(json_file):
    b = i['languages']
    str_b = ', '.join(b)
    str_b = str_b[:-2]
    a = MainCountry(country=i['country'], languages=str_b)
    a.save()